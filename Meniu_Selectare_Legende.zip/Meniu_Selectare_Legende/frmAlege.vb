﻿'################################################################################################
'Aplicaţie Visual Basic NET pentru lansarea selectivă în execuţie a unor aplicaţii pe touchscreen
'Autor: Florin Cătălin Tofan
'Data: 10 noiembrie 2017
'Versiunea 1.1
'################################################################################################



Imports System
Imports System.Threading
Imports System.Diagnostics
Imports System.ComponentModel

Public Class frmAlege
    Public Property ErrorDialog As Boolean = True

    Dim pbalta As New Process()
    Dim ppadure As New Process()
    Dim padmin As New Process()
    Dim appPath As String = Application.StartupPath()

    Dim Counter As Integer = 0

    Private Sub pic1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pic1.Click
        Dim app1path As String = appPath.ToString + "\db.exe"
        Try
            padmin.StartInfo.UseShellExecute = True
            padmin.StartInfo.FileName = app1path.ToString
            padmin.StartInfo.CreateNoWindow = False
            padmin.Start()
        Catch er As Exception
            Console.WriteLine((er.Message))
        End Try
    End Sub

    Private Sub pic2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pic2.Click
        Dim app2path As String = appPath.ToString + "\dp.exe"
        Try
            padmin.StartInfo.UseShellExecute = True
            padmin.StartInfo.FileName = app2path.ToString
            padmin.StartInfo.CreateNoWindow = False
            padmin.Start()
        Catch er As Exception
            Console.WriteLine((er.Message))
        End Try
    End Sub

    Private Sub picAdmin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picAdmin.Click

        Dim p() As Process
        p = Process.GetProcessesByName("administrare")
        If p.Count > 0 Then
            AppActivate("Panou Control Administrare")
        Else
            Dim app3path As String = appPath.ToString & "\administrare.exe"
            Try
                padmin.StartInfo.UseShellExecute = True
                padmin.StartInfo.FileName = app3path.ToString
                padmin.StartInfo.CreateNoWindow = False
                padmin.Start()
            Catch er As Exception
                Console.WriteLine((er.Message))
            End Try
        End If

    End Sub

    Private Sub frmAlege_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        Dim a As Integer
        While a < 3
            Me.Location = New Point(Me.Location.X + 20, Me.Location.Y)
            System.Threading.Thread.Sleep(50)
            Me.Location = New Point(Me.Location.X - 20, Me.Location.Y)
            System.Threading.Thread.Sleep(50)
            a += 1
            picAdmin.Enabled = False
            picAdmin.Visible = False
        End While
        picAdmin.Enabled = True
        picAdmin.Visible = True
    End Sub

    Private Sub frmAlege_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub picAtinge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picAtinge.Click
        Dim a As Integer
        While a < 3
            lblSelectare.ForeColor = Color.Red
            lblSelectare.Refresh()
            System.Threading.Thread.Sleep(300)
            lblSelectare.ForeColor = Color.Black
            lblSelectare.Refresh()
            System.Threading.Thread.Sleep(300)
            a += 1
        End While
    End Sub

End Class
