﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAlege
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAlege))
        Me.pic1 = New System.Windows.Forms.PictureBox()
        Me.pic2 = New System.Windows.Forms.PictureBox()
        Me.lblSelectare = New System.Windows.Forms.Label()
        Me.picAtinge = New System.Windows.Forms.PictureBox()
        Me.picAdmin = New System.Windows.Forms.PictureBox()
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAtinge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAdmin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic1
        '
        Me.pic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic1.Image = CType(resources.GetObject("pic1.Image"), System.Drawing.Image)
        Me.pic1.Location = New System.Drawing.Point(12, 88)
        Me.pic1.Name = "pic1"
        Me.pic1.Size = New System.Drawing.Size(400, 300)
        Me.pic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic1.TabIndex = 0
        Me.pic1.TabStop = False
        '
        'pic2
        '
        Me.pic2.BackColor = System.Drawing.Color.Beige
        Me.pic2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic2.Image = CType(resources.GetObject("pic2.Image"), System.Drawing.Image)
        Me.pic2.Location = New System.Drawing.Point(488, 88)
        Me.pic2.Name = "pic2"
        Me.pic2.Size = New System.Drawing.Size(400, 300)
        Me.pic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic2.TabIndex = 1
        Me.pic2.TabStop = False
        '
        'lblSelectare
        '
        Me.lblSelectare.AutoSize = True
        Me.lblSelectare.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblSelectare.Location = New System.Drawing.Point(171, 34)
        Me.lblSelectare.Name = "lblSelectare"
        Me.lblSelectare.Size = New System.Drawing.Size(553, 31)
        Me.lblSelectare.TabIndex = 2
        Me.lblSelectare.Text = "Vă rugăm să selectaţi una dintre legende:"
        Me.lblSelectare.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picAtinge
        '
        Me.picAtinge.Image = CType(resources.GetObject("picAtinge.Image"), System.Drawing.Image)
        Me.picAtinge.Location = New System.Drawing.Point(418, 68)
        Me.picAtinge.Name = "picAtinge"
        Me.picAtinge.Size = New System.Drawing.Size(64, 50)
        Me.picAtinge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAtinge.TabIndex = 4
        Me.picAtinge.TabStop = False
        '
        'picAdmin
        '
        Me.picAdmin.BackColor = System.Drawing.Color.Transparent
        Me.picAdmin.Image = CType(resources.GetObject("picAdmin.Image"), System.Drawing.Image)
        Me.picAdmin.Location = New System.Drawing.Point(426, 340)
        Me.picAdmin.Name = "picAdmin"
        Me.picAdmin.Size = New System.Drawing.Size(48, 48)
        Me.picAdmin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picAdmin.TabIndex = 5
        Me.picAdmin.TabStop = False
        '
        'frmAlege
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Beige
        Me.ClientSize = New System.Drawing.Size(900, 400)
        Me.ControlBox = False
        Me.Controls.Add(Me.picAdmin)
        Me.Controls.Add(Me.picAtinge)
        Me.Controls.Add(Me.lblSelectare)
        Me.Controls.Add(Me.pic2)
        Me.Controls.Add(Me.pic1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAlege"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAtinge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAdmin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pic1 As System.Windows.Forms.PictureBox
    Friend WithEvents pic2 As System.Windows.Forms.PictureBox
    Friend WithEvents lblSelectare As System.Windows.Forms.Label
    Friend WithEvents picAtinge As System.Windows.Forms.PictureBox
    Friend WithEvents picAdmin As System.Windows.Forms.PictureBox

End Class
